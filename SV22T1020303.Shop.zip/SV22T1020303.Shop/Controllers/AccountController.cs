﻿using LiteCommerce.BusinessLayers;
using LiteCommerce.Models.Security;
using LiteCommerce.Shop;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SV22T1020303.BusinessLayers;
using SV22T1020303.Shop.Models.Account;

namespace SV22T1020303.Shop.Controllers
{
    public class AccountController : Controller
    {
        private async Task<List<SelectListItem>> GetProvincesAsync()
        {
            var list = new List<SelectListItem>()
            {
                new SelectListItem() { Value = "", Text = "-- Tỉnh/Thành phố --" }
            };

            var provinces = await DictionaryDataService.ListProvincesAsync();
            foreach (var item in provinces)
            {
                list.Add(new SelectListItem()
                {
                    Value = item.ProvinceName,
                    Text = item.ProvinceName
                });
            }
            return list;
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult Login(string? returnUrl = "")
        {
            if (User.Identity != null && User.Identity.IsAuthenticated)
                return RedirectToAction("Index", "Home");

            ViewBag.ReturnUrl = returnUrl;
            return View(new LoginViewModel());
        }

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = "")
        {
            ViewBag.ReturnUrl = returnUrl;

            if (!ModelState.IsValid)
                return View(model);

            string email = model.Email.Trim();
            string passwordHash = CryptHelper.HashMD5(model.Password);

            var account = await CustomerAccountDataService.AuthorizeAsync(email, passwordHash);
            if (account == null)
            {
                ModelState.AddModelError("", "Email hoặc mật khẩu không đúng.");
                return View(model);
            }

            var customer = await PartnerDataService.GetCustomerAsync(account.CustomerID);
            if (customer == null)
            {
                ModelState.AddModelError("", "Không tìm thấy thông tin khách hàng.");
                return View(model);
            }

            if (customer.IsLocked || !account.IsActive)
            {
                ModelState.AddModelError("", "Tài khoản hiện đang bị khóa.");
                return View(model);
            }

            var userData = new WebUserData()
            {
                UserId = customer.CustomerID.ToString(),
                UserName = account.Email,
                DisplayName = customer.CustomerName,
                Email = account.Email,
                Photo = "",
                Roles = new List<string>() { "customer" }
            };

            var authProperties = new AuthenticationProperties
            {
                IsPersistent = model.RememberMe
            };

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                userData.CreatePrincipal(),
                authProperties
            );

            TempData["SuccessMessage"] = "Đăng nhập thành công.";

            if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("Index", "Home");
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> Register()
        {
            ViewBag.Provinces = await GetProvincesAsync();
            return View(new RegisterViewModel());
        }

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            ViewBag.Provinces = await GetProvincesAsync();

            if (!ModelState.IsValid)
                return View(model);

            string email = model.Email.Trim();

            if (await CustomerAccountDataService.ExistsByEmailAsync(email))
            {
                ModelState.AddModelError(nameof(model.Email), "Email này đã được sử dụng.");
                return View(model);
            }

            try
            {
                var customer = model.ToCustomer();
                customer.Email = email;

                int newCustomerId = await PartnerDataService.AddCustomerAsync(customer);

                var account = new CustomerAccount()
                {
                    CustomerID = newCustomerId,
                    Email = email,
                    PasswordHash = CryptHelper.HashMD5(model.Password),
                    IsActive = true
                };

                await CustomerAccountDataService.AddAsync(account);

                TempData["SuccessMessage"] = "Đăng ký thành công. Mời bạn đăng nhập.";
                return RedirectToAction("Login");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Không thể đăng ký: " + ex.Message);
                return View(model);
            }
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Profile()
        {
            var userData = User.GetUserData();
            if (userData == null || string.IsNullOrEmpty(userData.UserId))
                return RedirectToAction("Login");

            int customerID = int.Parse(userData.UserId);
            var customer = await PartnerDataService.GetCustomerAsync(customerID);
            if (customer == null)
                return RedirectToAction("Index", "Home");

            ViewBag.Provinces = await GetProvincesAsync();
            return View(customer.ToProfileViewModel());
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(ProfileViewModel model)
        {
            ViewBag.Provinces = await GetProvincesAsync();

            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var userData = User.GetUserData();
                if (userData == null || string.IsNullOrEmpty(userData.UserId))
                    return RedirectToAction("Login");

                model.CustomerID = int.Parse(userData.UserId);

                var currentCustomer = await PartnerDataService.GetCustomerAsync(model.CustomerID);
                if (currentCustomer == null)
                    return RedirectToAction("Login");

                var customer = model.ToCustomer();
                customer.IsLocked = currentCustomer.IsLocked;

                await PartnerDataService.UpdateCustomerAsync(customer);

                TempData["SuccessMessage"] = "Cập nhật thông tin thành công! ✨";
                return RedirectToAction("Profile");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(model);
            }
        }

        [Authorize]
        [HttpGet]
        public IActionResult ChangePassword()
        {
            return View(new ChangePasswordViewModel());
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var userData = User.GetUserData();
            if (userData == null || string.IsNullOrEmpty(userData.UserId))
                return RedirectToAction("Login");

            int customerID = int.Parse(userData.UserId);

            // 1. Kiểm tra tài khoản
            var account = await CustomerAccountDataService.GetByCustomerIdAsync(customerID);
            if (account == null)
            {
                ModelState.AddModelError("", "Không tìm thấy tài khoản.");
                return View(model);
            }

            // 2. Kiểm tra mật khẩu cũ
            string oldHash = CryptHelper.HashMD5(model.OldPassword);
            if (!string.Equals(account.PasswordHash, oldHash, StringComparison.OrdinalIgnoreCase))
            {
                ModelState.AddModelError(nameof(model.OldPassword), "Mật khẩu cũ không đúng.");
                return View(model);
            }

            // 3. Cập nhật mật khẩu mới
            string newHash = CryptHelper.HashMD5(model.NewPassword);
            bool result = await CustomerAccountDataService.ChangePasswordAsync(customerID, newHash);

            if (result)
            {
                TempData["SuccessMessage"] = "Đổi mật khẩu thành công! 🔑";
                return RedirectToAction("Profile");
            }

            ModelState.AddModelError("", "Lỗi hệ thống, không thể đổi mật khẩu.");
            return View(model);
        }

        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }

        [AllowAnonymous]
        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}