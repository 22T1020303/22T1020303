﻿document.addEventListener("DOMContentLoaded", function () {
    initMobileMenu();
    initPopupSystem();
    initAnimatedButtons();
    initAutoActiveNav();
    initScrollReveal();
    initCardEffects();
});

function initMobileMenu() {
    const toggle = document.querySelector("[data-mobile-toggle]");
    const menu = document.querySelector("[data-mobile-menu]");
    if (!toggle || !menu) return;

    toggle.addEventListener("click", function () {
        menu.classList.toggle("d-none");
    });
}

function initPopupSystem() {
    const overlay = document.getElementById("shopPopupOverlay");
    if (!overlay) return;

    overlay.addEventListener("click", function (e) {
        if (e.target.id === "shopPopupOverlay") closeShopPopup();
    });

    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") closeShopPopup();
    });
}

function showShopPopup(message = "", title = "Thành công") {
    const overlay = document.getElementById("shopPopupOverlay");
    if (!overlay) return;

    const popupTitle = overlay.querySelector("h4");
    const popupText = overlay.querySelector("p");

    if (popupTitle) popupTitle.innerText = title;
    if (popupText) popupText.innerText = message || "Chúc bạn có những trải nghiệm mua sắm thật dịu dàng và ngọt ngào tại Dreamy Shop.";

    overlay.classList.add("show");
    document.body.style.overflow = "hidden";
}

function closeShopPopup() {
    const overlay = document.getElementById("shopPopupOverlay");
    if (!overlay) return;
    overlay.classList.remove("show");
    document.body.style.overflow = "";
}

function initAnimatedButtons() {
    const buttons = document.querySelectorAll(".dreamy-btn, .btn-main, .dreamy-btn-outline");
    buttons.forEach(btn => {
        btn.addEventListener("mouseenter", () => btn.classList.add("hover-lift"));
        btn.addEventListener("mouseleave", () => btn.classList.remove("hover-lift"));
    });
}

function initAutoActiveNav() {
    const currentPath = window.location.pathname.toLowerCase();
    const navLinks = document.querySelectorAll(".shop-link, .nav-link");

    navLinks.forEach(link => {
        const href = (link.getAttribute("href") || "").toLowerCase();
        if (href === currentPath || (href !== "/" && currentPath.startsWith(href.replace("~", "")))) {
            link.classList.add("active");
        }
    });
}

function initScrollReveal() {
    const items = document.querySelectorAll(".fade-up, .dreamy-card, .product-card-item");
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("in-view");
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    items.forEach(item => observer.observe(item));
}

function initCardEffects() {
    const cards = document.querySelectorAll(".dreamy-card, .product-card-item");
    cards.forEach(card => {
        card.addEventListener("mousemove", (e) => {
            const rect = card.getBoundingClientRect();
            const x = (e.clientX - rect.left) / rect.width - 0.5;
            const y = (e.clientY - rect.top) / rect.height - 0.5;

            card.style.transform = `perspective(1000px) rotateX(${y * -8}deg) rotateY(${x * 8}deg) translateY(-6px)`;
        });

        card.addEventListener("mouseleave", () => {
            card.style.transform = "";
        });
    });
}